//
//  ViewController.m
//  banner
//
//  Created by sun on 16/1/12.
//  Copyright © 2016年 sun. All rights reserved.
//
#define WIDTH   self.view.frame.size.width
#define HEIGHT  self.view.frame.size.height


#import "ViewController.h"

#define SCREEN_WIDTH  [[UIScreen mainScreen] bounds].size.width

#define SCROLL_WIDTH  WIDTH*59/75
#define SCROLL_HEIGHT WIDTH*30/(75)


#define IMAGE_WIDTH   WIDTH*57/75
#define IMAGE_HEIGHT  SCROLL_HEIGHT


//#define SCREEN_WIDTH  [[UIScreen mainScreen] bounds].size.width
//
//#define SCROLL_WIDTH  SCREEN_WIDTH*59/75
//#define SCROLL_HEIGHT SCREEN_WIDTH*59*301/(75*590)
//
//
//#define IMAGE_WIDTH   SCREEN_WIDTH*572/750
//#define IMAGE_HEIGHT  SCREEN_WIDTH*572*301/(750*572)

@interface ViewController ()<UIScrollViewDelegate>
{
    NSArray *imageArray;
}

@property (nonatomic, strong) UIScrollView *scrollerView;
@property (nonatomic, strong) UIWindow *myWindow;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"SCREEN_WIDTH = %f SCROLL_WIDTH = %f SCROLL_HEIGHT = %f IMAGE_WIDTH = %f IMAGE_HEIGHT = %f",SCREEN_WIDTH,SCROLL_WIDTH,SCROLL_HEIGHT,IMAGE_WIDTH,IMAGE_HEIGHT);
    

    _scrollerView = [[UIScrollView alloc] initWithFrame:CGRectMake(45, 20, SCREEN_WIDTH-90, SCROLL_HEIGHT)];
    _scrollerView.backgroundColor = [UIColor orangeColor];
    _scrollerView.delegate = self;
    self.view.clipsToBounds = YES;
    _scrollerView.clipsToBounds = NO;
    [self.view addSubview:_scrollerView];

    imageArray = @[@"产品1.jpg",@"产品2.jpg",@"产品3.jpg",@"产品4.jpg",@"产品5.jpg",@"产品1.jpg",@"产品2.jpg",@"产品3.jpg",@"产品4.jpg",@"产品5.jpg"];
    for (NSInteger i = 0; i <imageArray.count; i ++) {
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake((SCREEN_WIDTH-90) *i, 0, SCROLL_WIDTH, SCROLL_HEIGHT)];
        view.backgroundColor = [UIColor cyanColor];
        [_scrollerView addSubview:view];
        
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(5, 0, (SCREEN_WIDTH-100), IMAGE_HEIGHT)];
        //imageView.backgroundColor = [UIColor whiteColor];
        imageView.contentMode = UIViewContentModeScaleAspectFit;
        imageView.image = [UIImage imageNamed:imageArray[i]];
        [view addSubview:imageView];
        NSLog(@"width = %f height = %f",CGRectGetWidth(imageView.frame),CGRectGetHeight(imageView.frame));
    }
    _scrollerView.contentSize = CGSizeMake((SCREEN_WIDTH-90) *imageArray.count, IMAGE_HEIGHT);
    _scrollerView.pagingEnabled = YES;
    _scrollerView.contentOffset = CGPointMake((SCREEN_WIDTH-90) *2, 0);

}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
//    滑动结束
    NSLog(@"scrollView.contentOffset.x = %f",scrollView.contentOffset.x);
    
    if (scrollView.contentOffset.x == (SCREEN_WIDTH-90)) {
        scrollView.contentOffset = CGPointMake((SCREEN_WIDTH-90) *(1+(imageArray.count/2)), 0);
    }
    if (scrollView.contentOffset.x == (SCREEN_WIDTH-90) *(2+(imageArray.count/2))) {
        scrollView.contentOffset = CGPointMake((SCREEN_WIDTH-90) *2, 0);
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
